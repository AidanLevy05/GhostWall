"""HTTP defense package."""
