"""Defense solution package."""
