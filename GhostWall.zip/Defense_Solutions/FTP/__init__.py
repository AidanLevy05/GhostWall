"""FTP defense package."""
