#!/bin/sh
sudo lsof -i :22
